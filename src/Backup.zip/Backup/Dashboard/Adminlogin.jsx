import React, { useState, useEffect } from 'react'
import { auth } from '../firebase';
import './CSS/Adminlogin.css';
import Admindashboard from './Admindashboard';
  
const Adminlogin = () => {

    const [user, setUser] = useState(null)
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const clearInputs = () => {
        setEmail('');
        setPassword('');
    }

    const handleLogin = (e) => {
        e.preventDefault();
        auth.signInWithEmailAndPassword(email, password)
        .then(user => {
            console.log(user)
        }).catch(err => {
            console.log(err)
        })
    }

    useEffect(() => {
        const unsubscribe = auth.onAuthStateChanged((userAuth) => {
          const user = {
            uid: userAuth?.uid,
            email: userAuth?.email
          }
          if (userAuth) {
            clearInputs();
            setUser(user);
          } else {
            setUser(null);
          }
        })
        return unsubscribe;
      }, [])

    return (
        <>
            {user ? ( <Admindashboard /> ) : (
                <div className="loginblock">
                    <h3>⇀ Admin Login</h3> 
                    <hr/>
                    
                    <div className="row mainlogin">
                        <div className="col-md-4">
                            <form className="form-login" onSubmit={handleLogin}>
                                    <input 
                                        type="text"
                                        autoFocus
                                        required
                                        value={email}
                                        placeholder="Username or Email"
                                        onChange={(e) => setEmail(e.target.value)}
                                    />
                                    <input 
                                        type="password"
                                        autoFocus
                                        required
                                        value={password}
                                        placeholder="Password"
                                        onChange={(e) => setPassword(e.target.value)}
                                    />
                                <button>Login</button>
                            </form>
                        </div>

                    
                    </div>

                </div>
            )}
        </>
  
    )
}
  
export default Adminlogin;