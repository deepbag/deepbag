import React, { useState, useEffect } from 'react';
import db from '../firebase'; // firestore firebase path 
import './CSS/Admindashboard.css'; // Admindashboard css path
import deepbag from '../Image/deepbag.png';
import { auth } from '../firebase'; // auth firebase path

import { CKEditor } from '@ckeditor/ckeditor5-react'; // CKeditor library path
import ClassicEditor from '@ckeditor/ckeditor5-build-classic'; // CKeditor Clssiceditor style library path

export default function Admindashboard() {

    // fetch blog post from firebase start
    const [blogs, setBlogs] = useState([]);
    useEffect(() => {
        db.collection('Blogposts').onSnapshot((snapshot) => {
            setBlogs(snapshot.docs.map(doc=>{
                return{
                    id: doc.id,
                    ...doc.data(),
                };
            }))
        })
        
        // fetch current date to store firebase start
        const date = new Date().getDate();
        const month = new Date().getMonth();
        const year = new Date().getFullYear();
        const today = date + '-' + month + '-' + year;
        setTodaydate(today);
        // fetch current date to store firebase start
    }, [])
    // fetch blog post from firebase end

    const totalcount = blogs.length; // fetch total blog posts

    const [blogtitle, setBlogtitle] = useState("");
    const [blogauthor, setBlogauthor] = useState("");
    const [blogcontent, setBlogcontent] = useState();
    const [blogimgurl, setBlogimgurl] = useState("");
    const [loader, setLoader] = useState(false);
    const [todaydate, setTodaydate] = useState("");
    const [blogexcerpt, setBlogexcerpt] = useState("");

    // store input data to firestore start
    const handleSubmit =  (e) => {
        e.preventDefault();
        setLoader(true);
    
        // Upload post Data in Firebase Firestore Start
        db.collection("Blogposts")
          .add({
            blogtitle: blogtitle,
            blogauthor: blogauthor,
            blogcontent: blogcontent,
            blogimgurl: blogimgurl,
            todaydate: todaydate,
            blogexcerpt: blogexcerpt
          })
          .then(() => {
            setLoader(false);
            alert("Your post has been uploaded👍");
          })
          .catch((error) => {
            alert(error.message);
            setLoader(false);
          });
          // Upload post Data in Firebase Firestore end
    
        setBlogtitle("");
        setBlogauthor("");
        setBlogimgurl("");
        setBlogcontent("");
        setBlogexcerpt("");
      };
      // store input data to firestore start
   

    return (
        <>
            <div className="dashblock">
                <h3>⇀ Hello, Deep Bag! <span className="logout-btn" onClick={() => auth.signOut()}>Logout ⚡</span></h3> 
                <hr/>
                <div className="row">
                    <div className="col-md-8 postformblock">
                        
                        {/* Post From start */}
                        <form className="formblock" onSubmit={handleSubmit}>
                            <input
                                autoFocus
                                required
                                placeholder="Blog Title ⇀ Minimum 35 Characters"
                                value={blogtitle}
                                onChange={(e) => setBlogtitle(e.target.value)}
                                className="blogtitleinput"
                                minLength="35" 
                            />

                            <input
                                autoFocus
                                required
                                placeholder="Blog Author"
                                value={blogauthor}
                                onChange={(e) => setBlogauthor(e.target.value)}
                                className="blogauthorinput"
                            />

                            <input 
                                autoFocus
                                required
                                type="url" 
                                placeholder="Blog Image URL ⇀ Upload image in Cloud"
                                value={blogimgurl}
                                onChange={(e) => setBlogimgurl(e.target.value)}
                                className="blogimgurlinput"
                            />

                            <input
                                autoFocus
                                required
                                type="text" 
                                placeholder="Blog Excerpt ⇀ Minimum 80 Characters"
                                value={blogexcerpt}
                                onChange={(e) => setBlogexcerpt(e.target.value)}
                                className="blogexcerpt"
                                minLength="80" 
                                maxLength="120"
                            />

            
                            <CKEditor 
                                editor={ ClassicEditor }
                                data={blogcontent}
                                onChange={(event, editor)=>{
                                    setBlogcontent(editor.getData())
                                }}
                            />

                            <button
                                type="submit"
                                style={{ background: loader ? "#ccc" : " tomato" }}
                            >
                                Upload Post
                            </button>
                        </form>
                        {/* Post From end */}
                    </div>
                    
                    {/* Author about and total post start */}
                    <div className="col-md-4">
                        <div className="informationblock">
                            <p><img src={deepbag} alt="deepbag" width="130px" /></p>
                            <h4>Er. Deep Bag</h4>
                            <h6>I'm an Engineer⚡ or Developer☕ or Photographer🎓 or Traveler✌ or many things & also a Vlogger.</h6>
                            <p className="totalpost">Total Post ⇀ {totalcount}</p>
                       </div>
                    </div>
                    {/* Author about and total post end */}
                </div>
                <hr className="hrtag"/>

                {/* Show total posts in dashboard start */}
                <table className="table table-bordered styled-table">
                        <thead>
                        <tr>
                            <th>Sl.No.</th>
                            <th>Post Title</th>
                            <th>Post Author</th>
                            <th>Date</th>
                            <th>Operation</th>
                        </tr>
                        </thead>
                        <tbody>
                        {blogs.map((blogspost, index)=>(
                            <tr key={index}>
                                <td>{index+1}</td>
                                <td>{blogspost.blogtitle}</td>
                                <td>{blogspost.blogauthor}</td>
                                <td>{blogspost.todaydate}</td>
                                <td>
                                    <button onClick={()=>{
                                        if(window.confirm(`Are You Sure You Want to Delete "${blogspost.blogtitle}" Article! ✌`)){
                                            db.collection("Blogposts").doc(blogspost.id).delete();
                                        }
                                    }} className="postdelete">Delete</button>
                                </td>
                            </tr>
                        ))}
                            
                        </tbody>
                    </table>
                    {/* Show total posts in dashboard end */}
            </div>
        </>
    )
}
