import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'; // bootstrap library path
import '../Styles/Resume.css'; // resume css path

import resumeEducation from '../JSON/resumeEducation.json'; // education json path
import resumeExperience from '../JSON/resumeExperience.json'; // experience json path
import resumeStrengths from '../JSON/resumeStrengths.json'; // strengths json path
import resumeSoftskills from '../JSON/resumeSoftskills.json'; // softskill json path
import resumeDesign from '../JSON/resumeDesign.json'; // design json path
import resumeCoding from '../JSON/resumeCoding.json'; // coding json path
import resumeOther from '../JSON/resumeOther.json'; // Other json path

export default function Resume () {
    return (
        <>
            <div className="resumeblock">
                <h3>⇀ Resume</h3>
                <hr/>
                <div className="edeblock">
                    {/* Education Experience Strengths Block Start */}
                    <div className="edblock"> 
                        <h3>⇀ Education</h3>
                        {
                            resumeEducation.map((resumedata, index)=>{
                                return(
                                    <div className="college object van move-right" id="axis" key={index}>
                                        <h4>{resumedata.course} ✔</h4>
                                        <h5>{resumedata.branchyear}</h5>
                                        <h6>{resumedata.college}</h6>
                                    </div>
                                )})
                        }
                        
                        <h3>⇀ Experience</h3>
                        {
                            resumeExperience.map((resumeex, index)=>{
                                return(
                                    <div className="college object van move-right" id="axis" key={index}>
                                        <h4>{resumeex.position} ✔</h4>
                                        <h5>{resumeex.workyear}</h5>
                                        <h6>{resumeex.where}</h6>
                                    </div>
                                )})
                        }

                        <h3>⇀ Strengths</h3>
                        {
                            resumeStrengths.map((resumestr, index)=>{
                                return(
                                    <div className="college object van move-right" id="axis" key={index}>
                                        <h4>{resumestr.firstStrength} | {resumestr.secondStrength} ✔</h4>
                                        <h5>{resumestr.strengthAbout}</h5>
                                    </div>
                                )})
                        }  
                    </div>
                    {/* Education Experience Strengths Block Start */}

                    {/* Design coding other soft skill Block Start */}
                    <div className="deblock">
                        <h3>⇀ Design Skills</h3>
                        <div className="designbar">
                            {
                                resumeDesign.map((design)=>{
                                    return(
                                        <>
                                            <h4>{design.designSkill} ✔</h4>
                                            <div className="progress" style={{marginBottom: '12px'}}>
                                                <span className="progress-bar" role="progressbar" style={{width: `${design.percentage}`}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">{design.percentage}</span>
                                            </div>
                                        </>
                                    )
                                })
                            }
                        </div>

                        <h3>⇀ Coding Skills</h3>
                        <div className="designbar">
                            {
                                resumeCoding.map((coding)=>{
                                    return(
                                        <>
                                            <h4>{coding.codingSkill} ✔</h4>
                                            <div className="progress" style={{marginBottom: '12px'}}>
                                                <span className="progress-bar" role="progressbar" style={{width: `${coding.percentage}`}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">{coding.percentage}</span>
                                            </div>
                                        </>
                                    )
                                })
                            }
                        </div>

                        <h3>⇀ Other Skills</h3>
                        <div className="designbar">
                            {
                                resumeOther.map((other)=>{
                                    return(
                                        <>
                                            <h4>{other.otherSkill} ✔</h4>
                                            <div className="progress" style={{marginBottom: '12px'}}>
                                                <span className="progress-bar" role="progressbar" style={{width: `${other.percentage}`}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">{other.percentage}</span>
                                            </div>
                                        </>
                                    )
                                })
                            }
                        </div>

                        <h3>⇀ Soft Skills</h3>
                        {
                            resumeSoftskills.map((softskills, index)=>{
                                return(
                                    <div className="designbar" key={index}>
                                        <h5>{softskills.softskill} ✔</h5>
                                        <h6>{softskills.softAbout}</h6>
                                    </div>
                                )
                            })
                        }
                    </div>
                    {/* Design coding other soft skill Block Start */}
                </div>
            </div>
        </>
    )
}

