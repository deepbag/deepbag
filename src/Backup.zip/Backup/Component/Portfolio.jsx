import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'; // bootstrap library path
import '../Styles/Portfolio.css'; // portfolio css path

import AliceCarousel from 'react-alice-carousel'; // AliceCarousel Library path
import 'react-alice-carousel/lib/alice-carousel.css'; // AliceCarousel Library css path


export default function Portfolio() {

    // Image link click function start
    const openInNewTab = (url) => {
        const newWindow = window.open(url, '_blank', 'noopener,noreferrer')
        if (newWindow) newWindow.opener = null
      }
    // Image link click function end

    // AliceCarousel carousel config start
    const handleDragStart = (e) => e.preventDefault();

    const responsive = {
        0: { items: 1 },
        568: { items: 2 },
        1024: { items: 4 },
    };

    // Carousel Images with diffrent category start
    const reactImages = [
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/react/covaxin.png" alt="covaxin" onDragStart={handleDragStart} onClick={() => openInNewTab('https://onevaxind.web.app/')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/react/onereader.png" alt="onereader" onDragStart={handleDragStart} onClick={() => openInNewTab('https://readerio.web.app/')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/react/reactresume.png" alt="reactresume" onDragStart={handleDragStart} onClick={() => openInNewTab('https://deepbag.github.io/Resume-Reactjs/')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/react/blogpattern.png" alt="blogpattern" onDragStart={handleDragStart} onClick={() => openInNewTab('https://deepbag.github.io/blog-pattern-react/')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/react/digitalclock.png" alt="digitalclock" onDragStart={handleDragStart} onClick={() => openInNewTab('https://deepbag.github.io/digital-clock-reactjs/')} />,
      ];
    
    const wpImages = [
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/wordpress/aafsl.png" alt="aafsl" onDragStart={handleDragStart} onClick={() => openInNewTab('https://aafsl.com/')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/wordpress/abkleasing.png" alt="abkleasing" onDragStart={handleDragStart} onClick={() => openInNewTab('https://abkleasing.com/')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/wordpress/aspiretechno.png" alt="aspiretechno" onDragStart={handleDragStart} onClick={() => openInNewTab('https://aspiretechno.co.in/')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/wordpress/badhobharat.png" alt="badhobharat" onDragStart={handleDragStart} onClick={() => openInNewTab('https://badhobharat.in/')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/wordpress/crazywin.png" alt="crazywin" onDragStart={handleDragStart} onClick={() => openInNewTab('https://crazywin.in/')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/wordpress/ebookdukan.png" alt="ebookdukan" onDragStart={handleDragStart} onClick={() => openInNewTab('https://ebookdukan.com/')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/wordpress/harinaamcs.png" alt="harinaamcs" onDragStart={handleDragStart} onClick={() => openInNewTab('http://harinaamcs.in/')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/wordpress/jointechinfra.png" alt="jointechinfra" onDragStart={handleDragStart} onClick={() => openInNewTab('https://jointechinfra.com/')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/wordpress/kanamrabari.png" alt="kanamrabari" onDragStart={handleDragStart} onClick={() => openInNewTab('https://kanamrabari.com/')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/wordpress/neukelp.png" alt="neukelp" onDragStart={handleDragStart} onClick={() => openInNewTab('https://neukelp.com/')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/wordpress/sajsyrup.png" alt="sajsyrup" onDragStart={handleDragStart} onClick={() => openInNewTab('https://www.sajsyrup.com/')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/wordpress/shortblogging.png" alt="shortblogging" onDragStart={handleDragStart} onClick={() => openInNewTab('https://shortblogging.com/')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/wordpress/stocktradingfno.png" alt="stocktradingfno" onDragStart={handleDragStart} onClick={() => openInNewTab('https://stocktradingfno.com/')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/wordpress/tebitechno.png" alt="tebitechno" onDragStart={handleDragStart} onClick={() => openInNewTab('https://tebitechnology.com/')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/wordpress/thefinansol.png" alt="thefinansol" onDragStart={handleDragStart} onClick={() => openInNewTab('http://www.thefinansol.com/')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/wordpress/thepeoplebazaar.png" alt="thepeoplebazaar" onDragStart={handleDragStart} onClick={() => openInNewTab('http://www.thefinansol.com/')} />,
      ];
    
    const photoImages = [
        <img src="https://images.unsplash.com/photo-1629360028061-26f689ff93f7?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=774&q=80" alt="nature" onDragStart={handleDragStart} onClick={() => openInNewTab('https://unsplash.com/photos/CBA7GpUmDAE')} />,
        <img src="https://images.unsplash.com/photo-1630507370767-7cad2a2eef30?ixid=MnwxMjA3fDB8MHxwcm9maWxlLXBhZ2V8OXx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" alt="nature" onDragStart={handleDragStart} onClick={() => openInNewTab('https://unsplash.com/photos/FNfOeXZD7nA')} />,
        <img src="https://images.unsplash.com/photo-1630507793833-75e9b427010f?ixid=MnwxMjA3fDB8MHxwcm9maWxlLXBhZ2V8OHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" alt="nature" onDragStart={handleDragStart} onClick={() => openInNewTab('https://unsplash.com/photos/s2DC3CM8-Sk')} />,
        <img src="https://images.unsplash.com/photo-1631189968011-0349582d41b7?ixid=MnwxMjA3fDB8MHxwcm9maWxlLXBhZ2V8Nnx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" alt="nature" onDragStart={handleDragStart} onClick={() => openInNewTab('https://unsplash.com/photos/1meQTfpxwzE')} />,
        <img src="https://images.unsplash.com/photo-1631189968412-e50196c786b6?ixid=MnwxMjA3fDB8MHxwcm9maWxlLXBhZ2V8NXx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" alt="nature" onDragStart={handleDragStart} onClick={() => openInNewTab('https://unsplash.com/photos/Illr_mK_tNc')} />,
        <img src="https://images.unsplash.com/photo-1631189596821-bb0f85434e2c?ixid=MnwxMjA3fDB8MHxwcm9maWxlLXBhZ2V8NHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" alt="nature" onDragStart={handleDragStart} onClick={() => openInNewTab('https://unsplash.com/photos/DprejUhSoTk')} />,
        <img src="https://images.unsplash.com/photo-1631189756874-381716095441?ixid=MnwxMjA3fDB8MHxwcm9maWxlLXBhZ2V8Mnx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" alt="nature" onDragStart={handleDragStart} onClick={() => openInNewTab('https://unsplash.com/photos/oDQHjF5Q5e4')} />,
      ];

    const certificates = [
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/Operate%20and%20Manage%20a%20Cloud%20Server.jpg" alt="alibaba cloud" onDragStart={handleDragStart} onClick={() => openInNewTab('https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/Operate%20and%20Manage%20a%20Cloud%20Server.jpg')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/react.jpg" alt="react" onDragStart={handleDragStart} onClick={() => openInNewTab('https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/react.jpg')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/CCNA200-301.jpg" alt="CCNA" onDragStart={handleDragStart} onClick={() => openInNewTab('https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/CCNA200-301.jpg')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/CLOUD%20COMPUTING.jpeg" alt="cloudcomputing" onDragStart={handleDragStart} onClick={() => openInNewTab('https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/CLOUD%20COMPUTING.jpeg')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/Elementor.jpg" alt="elementor" onDragStart={handleDragStart} onClick={() => openInNewTab('https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/Elementor.jpg')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/HTML.jpg" alt="html" onDragStart={handleDragStart} onClick={() => openInNewTab('https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/HTML.jpg')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/IMG_20191014_233907.jpg" alt="ethical" onDragStart={handleDragStart} onClick={() => openInNewTab('https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/IMG_20191014_233907.jpg')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/PHP.jpg" alt="php" onDragStart={handleDragStart} onClick={() => openInNewTab('https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/PHP.jpg')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/download.png" alt="wordpress" onDragStart={handleDragStart} onClick={() => openInNewTab('https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/download.png')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/jQuery.jpg" alt="jquery" onDragStart={handleDragStart} onClick={() => openInNewTab('https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/jQuery.jpg')} />,
        <img src="https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/js.jpg" alt="js" onDragStart={handleDragStart} onClick={() => openInNewTab('https://raw.githubusercontent.com/deepbag/git-cloud-storage/main/portfolio/certificate/js.jpg')} />,
      ];
    // Carousel Images with diffrent category end

    // AliceCarousel carousel config end

    return (
        <>
            <div className="portfolioblock">
                <h3>⇀ Portfolio</h3>
                <hr/>
                {/* Category Menu Bar start */}
                <div className="menu">
                    <a href="#react" className="menua">React</a>
                    <a href="#wp" className="menua">WordPress</a>
                    <a href="#pg" className="menua">Photography</a>
                    <a href="#certificate" className="menua">Certificates</a>
                </div>
                {/* Category Menu Bar end */}

                {/* Alice Carousel start item=category */}
                <div className="portfoliodata">
                    <h4 id="react">⇀ React Websites</h4>
                    <div className="reactimg">
                        <AliceCarousel 
                            items={reactImages} 
                            responsive={responsive} 
                            // infinite={true}
                            disableButtonsControls={true}
                            // autoPlay={true}
                            // autoPlayInterval={3000}
                            mouseTracking={true}
                        />
                    </div>

                    <h4 id="wp">⇀ WordPress Websites</h4>
                    <div className="reactimg">
                        <AliceCarousel 
                                items={wpImages} 
                                responsive={responsive} 
                                // infinite={true}
                                disableButtonsControls={true}
                                // autoPlay={true}
                                // autoPlayInterval={3000}
                                mouseTracking={true}
                        />
                    </div>

                    <h4 id="pg">⇀ Photography</h4>
                    <div className="reactimg">
                        <AliceCarousel 
                                items={photoImages} 
                                responsive={responsive} 
                                // infinite={true}
                                disableButtonsControls={true}
                                // autoPlay={true}
                                // autoPlayInterval={3000}
                                mouseTracking={true}
                        />
                    </div>

                    <h4 id="certificate">⇀ Certifications</h4>
                    <div className="reactimg">
                        <AliceCarousel 
                                items={certificates} 
                                responsive={responsive} 
                                // infinite={true}
                                disableButtonsControls={true}
                                // autoPlay={true}
                                // autoPlayInterval={3000}
                                mouseTracking={true}
                        />
                    </div>
                </div>
                {/* Alice Carousel end */}
            </div>
        </>
    )
}

