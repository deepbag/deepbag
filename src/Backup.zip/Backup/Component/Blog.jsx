import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'; // Bootstrap library Path
import '../Styles/Blog.css'; // blog css path
// import { NavLink } from 'react-router-dom';

export default function Blog() {
    return (
        <>
            <div className="blogblock">
                <h3>⇀ Blog Posts</h3>
                <hr/>
                {/* Blog Post Loop start */}
                <div className="row postblock">
                    {/* {
                        blogs.map((blogpost, index)=>(
                            <div className="col-md-4 singleblock" key={index}>
                                <div className="blogdata">
                                    <p style={{textAlign: 'center'}} ><img src={blogpost.blogimgurl} alt="covaxin" width="310px" height="160px" style={{objectFit: 'cover', borderRadius: '5px'}} /></p>
                                    <div className="singledatablock">
                                        <NavLink to={`/blogpost/${blogpost.id}`} >
                                            <h4>{blogpost.blogtitle}</h4>
                                        </NavLink>
                                        <p>{blogpost.blogexcerpt}</p>
                                    </div>
                                </div>
                            </div>
                        ))
                    }    */}
                </div>
                {/* Blog Post Loop end */}
            </div>
        </>
    )
}

