import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../Styles/Singlepost.css';
import db from '../firebase';
import parse from 'html-react-parser';

const Singlepost = ({match}) => {

    const id = match.params.id;

    // fetch data from firebase start
    const [blogs, setBlogs] = useState([]);
    useEffect(() => {
        db.collection('Blogposts')
        .doc(id)
        .get()
        .then((doc)=>setBlogs(doc.data()))
    }, [id])
    // fetch data from firebase end

    return (
        <>
            <div className="singlepostblock">
                <h3>⇀ {blogs.blogtitle}</h3> 
                <hr/>
                <img src={blogs.blogimgurl} alt="imgalt" />
                <p>{ parse(blogs.blogcontent) }</p>
            </div>
        </>
    )
}

export default Singlepost;
